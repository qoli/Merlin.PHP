<?php
set_include_path(get_include_path() . PATH_SEPARATOR . 'library/phpseclib');
require 'library/MainFunction.php';

dump($_SERVER);
