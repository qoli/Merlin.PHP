# 打包用指令

```bash
cd bin/autoupdate/
build.sh
```

