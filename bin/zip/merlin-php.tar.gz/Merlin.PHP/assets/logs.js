console.log ('%c ⛱ 看看我的知乎專欄 %c ➜ %c http://zhuanlan.zhihu.com/5mlstudio', 'color:#4163c0;font-weight: 800;', 'color:rgba(213, 36, 35, 1.00);', 'color:rgba(66, 133, 244, 1.00);font-weight: 800;');
console.log ('%c ✌️ %c Qoli Wong %c ❤️ 庫倪', 'color:#cb4577;', 'color:#4163c0;font-weight: 800', 'color:rgba(213, 36, 35, 1.00);font-weight: 800;');
console.log ('%c 🙋 %c 老師我有問題！ %c 👩 那麼你去看醫生吧。 ', 'color:rgba(36, 127, 84, 1.00);', 'color:rgba(213, 36, 35, 1.00);font-weight: 800', 'color:#4163c0;font-weight: 800;');
