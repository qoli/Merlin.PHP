<footer class="footer">
	<div class="footer-container">
		<!-- <hr/> -->
		<p class="text-muted">
			<i id="delay_icon" class="fa fa-circle red animated" aria-hidden="true"></i> Google：<span id="delay_time">testing</span> ． <a target="_self" href="/index.php/article?a=help">帮助</a>
		</p>
	</div>
</footer>
<div id="tips" class="tips animated hide">提示文字</div>
