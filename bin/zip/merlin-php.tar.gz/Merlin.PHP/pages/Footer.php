<footer class="footer">
	<div class="footer-container">
		<!-- <hr/> -->
		<p class="text-muted">
			<i id="delay_icon" class="fa fa-circle red animated" aria-hidden="true"></i> Google：<span id="delay_time">testing</span>
		</p>
	</div>
</footer>
