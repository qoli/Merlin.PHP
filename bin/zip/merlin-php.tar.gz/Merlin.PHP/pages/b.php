<div class="row hide">
	<div class="col-md-12" >
		<!-- <span class="mini-title">自定義命令</span> -->
		<!-- <br/> -->
		<input class="form-control" type="text" placeholder="自定義命令..." readonly>
		<br/>
		<button class="btn btn-default" style="margin-top: -20px;" >Run</button>
	</div>
</div>
<!-- <div class="clearfix" ></div> -->


<!-- <iframe id="iframeBox" class="iframe hide" src="/exec.php" frameborder="0" allowfullscreen></iframe> -->


		<footer class="footer">
			<div class="footer-container">
				<!-- <hr/> -->
				<p class="text-muted">
					@qoli wong ． <a href="http://zhuanlan.zhihu.com/5mlstudio">知乎專欄</a>
				</p>
			</div>
		</footer>
