<div class="row hide">
	<div class="col-md-12" >
		<!-- <span class="mini-title">自定義命令</span> -->
		<!-- <br/> -->
		<input class="form-control" type="text" placeholder="自定義命令..." readonly>
		<br/>
		<button class="btn btn-default" style="margin-top: -20px;" >Run</button>
	</div>
</div>
<!-- <div class="clearfix" ></div> -->


<iframe id="iframeBox" class="iframe hide" src="/exec.php" frameborder="0" allowfullscreen></iframe>


		<footer class="footer">
			<div class="footer-container">
				<!-- <hr/> -->
				<p class="text-muted">
					@qoli wong ． <a href="http://zhuanlan.zhihu.com/5mlstudio">知乎專欄</a>
				</p>
			</div>
		</footer>



	<div class="animated fadeInLeft">
		<div class="row">
			<div class="col-md-12" >
				<span class="mini-title">字體</span>
				<br/>
				<button class="need-transition btn btn-default active" >標準字體</button>
				<button class="need-transition btn btn-default" >大字體</button>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" >
				<span class="mini-title">按鈕</span>
				<br/>
				<button class="need-transition btn btn-default active" >標準按鈕</button>
				<button class="need-transition btn btn-default" >大按鈕</button>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12" >
				<span class="mini-title">開發中功能</span>
				<br/>
				<button class="need-transition btn btn-default" >隱藏</button>
				<button class="need-transition need-transition btn btn-default active" >顯示</button>
			</div>
		</div>
	</div>
