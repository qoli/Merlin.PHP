<script src="//cdn.bootcss.com/jquery/2.1.4/jquery.min.js"></script>
<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="//cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="assets/logs.js"></script>
<script src="assets/ui.js"></script>
<script src="assets/app.js"></script>
<script src="assets/standalone.js"></script>
</html>
