
<script>if (typeof module === 'object') {window.module = module; module = undefined;}</script>

<script src="assets/jquery.min.js"></script>
<script src="assets/bootstrap.min.js"></script>
<script src="assets/underscore-min.js"></script>
<!-- <script src="assets/Chart.min.js"></script>
<script src="assets/Chart.bundle.min.js"></script> -->
<script src="assets/logs.js"></script>
<script src="assets/ui.js"></script>
<script src="assets/app.js"></script>
<script src="assets/standalone.js"></script>

<script>if (window.module) module = window.module;</script>

</html>
