<script src="assets/jquery.min.js"></script>
<script src="assets/bootstrap.min.js"></script>
<script src="assets/underscore-min.js"></script>
<script src="assets/logs.js"></script>
<script src="assets/ui.js"></script>
<script src="assets/app.js"></script>
<script src="assets/standalone.js"></script>

<script>if (typeof module === 'object') {window.module = module; module = undefined;}</script>
<script>if (window.module) module = window.module;</script>

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-19058553-10', 'auto');
ga('send', 'pageview');
</script>

</html>
