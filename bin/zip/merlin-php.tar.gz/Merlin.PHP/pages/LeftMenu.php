<div id="leftMenu" class="leftMenu animated hide" >
	<ul>

		<li id="CloseMenu"> <a href="javascript: void(0)"><i class="fa fa-caret-left" aria-hidden="true"></i></span> 關閉菜單</a> </li>
		<li class="title"> <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span> 菜單</li>
		<li> <a class="Menu" target="_self" href="index.php"><i class="fa fa-circle-o" aria-hidden="true"></i> ShadowSocks</a> </li>
		<li> <a class="Menu" target="_self" href="index.php/setting"><i class="fa fa-cog" aria-hidden="true"></i> 設定</a> </li>
		<!--
		<li> <a class="Menu" target="_self" href="index.php/shadowvpn"><i class="fa fa-shield" aria-hidden="true"></i> ShadowVPN</a> </li>
		<li> <a class="Menu" target="_self" href="index.php/remote"><i class="fa fa-server" aria-hidden="true"></i> 遠程工具</a> </li>

		-->
		<li> <a href="http://192.168.1.1/"><i class="fa fa-link" aria-hidden="true"></i> 管理</a> </li>

 		<li class="title"> <i class="fa fa-info-circle" aria-hidden="true"></i> 關於 <span class="mini-text">版本 0.3</span></li>
		<li> <a class="Menu" target="_self" href="update.php"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i> 在線更新</a> </li>
		<li> <a class="Menu" target="_self" href="/index.php/article?a=update"><i class="fa fa-plus-circle" aria-hidden="true"></i> 更新記錄</a> </li>
		<li> <a class="Menu" target="_self" href="/index.php/article?a=help"><i class="fa fa-question-circle" aria-hidden="true"></i> 幫助</a> </li>
		<!-- <li> <a href="/"><i class="fa fa-refresh" aria-hidden="true"></i> 重新載入</a> </li> -->
	</ul>
</div>
