<div id="leftMenu" class="leftMenu animated hide" >
	<ul>
		<li id="CloseMenu"> <a href="javascript: void(0)"><i class="fa fa-caret-left" aria-hidden="true"></i></span> 關閉菜單</a> </li>
		<li class="title"> <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span> 菜單</li>
		<li> <a class="Menu" target="_self" href="index.php/home"><i class="fa fa-circle-o" aria-hidden="true"></i> ShadowSocks</a> </li>
		<li class="setting-dashboard"> <a class="Menu" target="_self" href="index.php/dashboard"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard</a> </li>
		<li class="setting-remote" > <a class="Menu" target="_self" href="index.php/remote"><i class="fa fa-server" aria-hidden="true"></i> Remote</a> </li>
		<!-- <li class=""> <a class="Menu" target="_self" href="index.php/plugin"><i class="fa fa-th-large" aria-hidden="true"></i> Plugin</a> </li> -->
		<li> <a class="Menu" target="_self" href="index.php/setting"><i class="fa fa-cog" aria-hidden="true"></i> 設定</a> </li>
		<!-- <li> <a class="Menu" target="_self" href="index.php/shadowvpn"><i class="fa fa-shield" aria-hidden="true"></i> ShadowVPN</a> </li> -->

		<li> <a href="http://<?=$GLOBALS['lanIP'];?>/"><i class="fa fa-link" aria-hidden="true"></i> 管理</a> </li>
		<li class="title"> <i class="fa fa-info-circle" aria-hidden="true"></i> 關於 <span class="mini-text">版本 <?=$GLOBALS['version']?></span></li>
		<li> <a class="Menu" target="_self" href="update.php"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i> 在線更新</a> </li>
		<li> <a class="Menu" target="_self" href="/index.php/article?a=update"><i class="fa fa-plus-circle" aria-hidden="true"></i> 更新記錄</a> </li>
		<li> <a class="Menu" target="_self" href="/index.php/article?a=help"><i class="fa fa-question-circle" aria-hidden="true"></i> 幫助</a> </li>
		<!-- <li> <a href="/"><i class="fa fa-refresh" aria-hidden="true"></i> 重新載入</a> </li> -->
	</ul>
</div>
