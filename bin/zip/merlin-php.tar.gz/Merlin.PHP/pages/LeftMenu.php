<div id="leftMenu" class="leftMenu hide animated" >
	<ul>

		<li class="title"> <span class="glyphicon glyphicon-menu-hamburger" aria-hidden="true"></span> MENU</li>
		<li id="CloseMenu"> <a href="javascript: void(0)"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> 返回</a> </li>
		<li> <a href="http://192.168.1.1/"><i class="fa fa-link" aria-hidden="true"></i> 路由器管理頁面</a> </li>

		<li class="title"> <i class="fa fa-circle-o" aria-hidden="true"></i> ShadowSocks </li>
		<li> <a class="btn" href="javascript: void(0)"><i class="fa fa-arrow-right" aria-hidden="true"></i> Game-Mode</a> </li>
		<li> <a class="btn" href="javascript: void(0)"><i class="fa fa-arrow-right" aria-hidden="true"></i> Game-V2</a> </li>
		<li> <a class="btn" href="javascript: void(0)"><i class="fa fa-stop" aria-hidden="true"></i> STOP</a> </li>

<!--
 		<li class="title"> <span class="glyphicon glyphicon-transfer" aria-hidden="true"></span> 線路切換</li>
		<li> <a href="">HK 89 阿里云 <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a> </li>
		<li> <a href="">HK 103 10M <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a> </li>
		<li> <a href="">HK 119 騰訊云 <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a> </li>
		<li> <a href="">HK 202 <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></a> </li>
-->

 		<li class="title"> <i class="fa fa-info-circle" aria-hidden="true"></i> 關於 <span class="mini-text">版本 0.1.160620</span></li>
		<li> <a class="Menu" target="_self" href="update.php"><i class="fa fa-arrow-circle-up" aria-hidden="true"></i> 在線更新</a> </li>
		<li> <a class="Menu" target="_self" href="article.php?a=help"><i class="fa fa-question-circle" aria-hidden="true"></i> 幫助</a> </li>
		<li> <a href="/"><i class="fa fa-refresh" aria-hidden="true"></i> 重新載入</a> </li>
	</ul>
</div>
