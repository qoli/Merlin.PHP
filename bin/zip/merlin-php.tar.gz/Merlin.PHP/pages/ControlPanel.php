		<div id="ControlPanel" class="animated fadeInLeft command">
			<div class="row">
				<div class="col-md-4" >
					<span class="mini-title">重啟服務</span>
					<br/>
					<button class="btn btn-default" >Network</button>
					<button class="btn btn-default" >ShadowSocks</button>
				</div>
				<div class="col-md-4 hide" >
					<span class="mini-title">ShadowSocks 設定</span>
					<br/>
					<button class="btn btn-default" >Game-Mode</button>
					<button class="btn btn-default" >Game-V2</button>
				</div>
				<div class="col-md-4" >
					<span class="mini-title">信息</span>
					<br/>
					<button class="btn btn-default" >網路測試</button>
					<button class="btn btn-default" >SS 信息</button>
					<button class="btn btn-default" >IP</button>
				</div>
			</div>
			<div class="clearfix" ></div>
		</div>
